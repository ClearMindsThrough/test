package com.amex.internal.b9.libra.constants;

public class KeyPrefixes {
    private KeyPrefixes() {
        throw new UnsupportedOperationException();
    }
    public static final String DERIVED_KEY = "LIBRA WALLET: derived key$";
    public static final String LIBRA_HASH_SUFFIX = "@@$$LIBRA$$@@";
    public static final String MASTER_KEY_SALT = "LIBRA WALLET: master key salt$";
    public static final String MNEMONIC_SALT = "LIBRA WALLET: mnemonic salt prefix$";
    public static final String DEFAULT_MNEMONIC_SALT_PREFIX = "LIBRA";

}
