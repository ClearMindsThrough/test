package com.amex.internal.b9.libra.admissioncontrol.query;

import org.immutables.value.Value;

@Value.Immutable
public interface GetAccountState {

    byte[] getAddress();
}
