package com.amex.internal.b9.libra.admissioncontrol.query;

import org.immutables.value.Value;

@Value.Immutable
public interface EventHandle {

    public byte[] getKey();

    public int getCount();

}
