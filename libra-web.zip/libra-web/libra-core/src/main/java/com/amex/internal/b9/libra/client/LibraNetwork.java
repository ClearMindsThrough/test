package com.amex.internal.b9.libra.client;

public enum LibraNetwork {
    testnet,
    mainnet;
}
