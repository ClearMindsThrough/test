package com.amex.internal.b9.libra.wallet;

import com.amex.internal.b9.libra.client.LibraClient;
import com.amex.internal.b9.libra.crypto.KeyPair;
import com.amex.internal.b9.libra.mnemonic.*;

import io.github.novacrypto.bip39.wordlists.English;
import org.apache.commons.lang3.RandomUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class LibraWallet {

    private static final Logger logger = LogManager.getLogger(LibraWallet.class);
    private static final String TEST_SALT = "Salt, pepper and a dash of sugar.";

    private long lastChild = 0;
    private KeyFactory keyFactory;
    private final Map<String, Account> accounts = new LinkedHashMap<>();

    public LibraWallet() {
        this(new Mnemonic(), null);
    }

    public LibraWallet(String words) {
        this( Mnemonic.from( words, English.INSTANCE ), null);
    }

    public LibraWallet(WalletConfig config) {
        this.keyFactory = KeyFactory.fromMnemonic(config.getMnemonic(), config.getSalt());
    }

    public LibraWallet(Mnemonic mnemonic, String salt) {
        this(new WalletConfig(mnemonic, salt));
    }

    public Account newAccount() {
        Account account = this.generateAccount( this.lastChild );
        this.lastChild++;
        return account;
    }

    public Account generateAccount(long depth) {
//        KeyPair keyPair = keyFactory.generateKey(depth);

//        Account account = new Account(keyPair);

        Account account = new Account( generateKey( depth ) );

        this.addAccount(account);
        return account;
    }

    public void addAccount(Account account) {
        accounts.put(account.getAddress(), account);
    }

    private ExtendedPrivKey generateKey( long depth ) {
        String words = IntStream.range(0, 18)
                .map(ignored -> RandomUtils.nextInt(0, Mnemonic.WORDS.size()))
                .mapToObj(Mnemonic.WORDS::get)
                .collect(Collectors.joining(" "));

        logger.info("Generated seed: {}", words);

        Seed seed = new Seed(Mnemonic.fromString(words), TEST_SALT);

        LibraKeyFactory libraKeyFactory = new LibraKeyFactory(seed);
        return libraKeyFactory.privateChild(new ChildNumber(depth));
    }

}
