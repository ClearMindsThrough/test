package com.amex.internal.b9.libra.constants;

public class PathValues {
    private PathValues() {
        throw new UnsupportedOperationException();
    }
    public static final String ACCOUNT_RESOURCE_PATH = "01217da6c6b3e19f1825cfb2676daecce3bf3de03cf26647c78df00b371b25cc97";
    public static final String ACCOUNT_SENT_EVENT_PATH = "01217da6c6b3e19f1825cfb2676daecce3bf3de03cf26647c78df00b371b25cc972f73656e745f6576656e74735f636f756e742f";
    public static final String ACCOUNT_RECEIVED_EVENT_PATH = "01217da6c6b3e19f1825cfb2676daecce3bf3de03cf26647c78df00b371b25cc972f72656365697665645f6576656e74735f636f756e742f";
}
