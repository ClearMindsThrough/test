package com.amex.internal.b9.libra.constants;

import org.bouncycastle.util.encoders.Hex;

public class HashSaltValues {
    private HashSaltValues() {
        throw new UnsupportedOperationException();
    }
    public static final byte[] RAW_TRANSACTION_HASH_SALT = Hex.decode("46f174df6ca8de5ad29745f91584bb913e7df8dd162e3e921a5c1d8637c88d16");

}
