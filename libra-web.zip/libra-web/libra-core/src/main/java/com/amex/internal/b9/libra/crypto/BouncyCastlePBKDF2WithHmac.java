package com.amex.internal.b9.libra.crypto;

import org.bouncycastle.crypto.Digest;
import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.digests.SHA3Digest;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;


public enum BouncyCastlePBKDF2WithHmac  implements PBKDF2WithHmac  {
    /**
     * PBKDF2WithHmacSHA3-256
     */
    PBKDF2WithHmacSHA3_256(new SHA3Digest(256), 2048, 256);

    private final Digest digest;

    private final int iterationCount;
    private final int keyLength;

    BouncyCastlePBKDF2WithHmac(Digest digest, int iterationCount, int keyLength) {
        this.digest = digest;
        this.iterationCount = iterationCount;
        this.keyLength = keyLength;
    }

    @Override
    public byte[] hash(char[] password, byte[] salt) {
        return hash(PBEParametersGenerator.PKCS5PasswordToUTF8Bytes(password), salt);
    }

    @Override
    public byte[] hash(byte[] password, byte[] salt) {
        PKCS5S2ParametersGenerator generator = new PKCS5S2ParametersGenerator(this.digest);
        generator.init(password, salt, this.iterationCount);
        KeyParameter key = (KeyParameter) generator.generateDerivedMacParameters(this.keyLength);
        return key.getKey();
    }

}
