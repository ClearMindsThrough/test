package com.amex.internal.b9.libra.wallet;

import com.amex.internal.b9.libra.crypto.KeyPair;
import com.amex.internal.b9.libra.mnemonic.ExtendedPrivKey;
import lombok.Getter;
import org.bouncycastle.jcajce.provider.digest.SHA3;
import org.bouncycastle.util.encoders.Hex;

public class Account {
    public static final String DEFAULT_ADDRESS = "0000000000000000000000000000000000000000000000000000000000000000";

    @Getter
    private final ExtendedPrivKey keyPair;

//    @Getter
//    private final KeyPair keyPair;
//
    private String address;

    public Account(ExtendedPrivKey keyPair) {
        this.keyPair = keyPair;
    }
//
//    public static Account fromSecretKey(byte[] secretKey) {
//        return new Account(KeyPair.fromSecretKey(secretKey));
//    }
//
    public String getAddress() {
        return this.keyPair.getAddress();
//        if (this.address == null) {
//            SHA3.Digest256 digest256 = new SHA3.Digest256();
//            digest256.update(this.keyPair.getPublicKey());
//            this.address = new String(Hex.encode(digest256.digest()));
//        }
//        return address;
    }
}
