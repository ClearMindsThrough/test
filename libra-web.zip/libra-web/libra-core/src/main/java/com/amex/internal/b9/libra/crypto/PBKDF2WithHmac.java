package com.amex.internal.b9.libra.crypto;

public interface PBKDF2WithHmac {
    byte[] hash(char[] password, byte[] salt);

    byte[] hash(byte[] password, byte[] salt);
}
