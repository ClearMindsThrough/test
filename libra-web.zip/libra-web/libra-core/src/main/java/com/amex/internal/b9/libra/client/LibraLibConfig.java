package com.amex.internal.b9.libra.client;

import lombok.Data;

@Data
public class LibraLibConfig {
    private final String host;
    private final int port;
    private final LibraNetwork network;
    private final String faucetServerHost;
    private String validatorSetFile;

    public LibraLibConfig(String host, int port, LibraNetwork network, String faucetServerHost) {
        this.host = host;
        this.port = port;
        this.network = network;
        this.faucetServerHost = faucetServerHost;
    }
}
