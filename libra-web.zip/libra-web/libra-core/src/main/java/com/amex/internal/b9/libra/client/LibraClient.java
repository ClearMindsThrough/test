package com.amex.internal.b9.libra.client;

import admission_control.AdmissionControlOuterClass;
import com.amex.internal.b9.libra.admissioncontrol.AdmissionControl;
import com.amex.internal.b9.libra.admissioncontrol.query.*;
import com.amex.internal.b9.libra.move.Move;
import com.amex.internal.b9.libra.wallet.Account;
import com.google.protobuf.ByteString;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import com.amex.internal.b9.libra.admissioncontrol.transaction.AddressArgument;
import com.amex.internal.b9.libra.admissioncontrol.transaction.ImmutableProgram;
import com.amex.internal.b9.libra.admissioncontrol.transaction.ImmutableTransaction;
import com.amex.internal.b9.libra.admissioncontrol.transaction.SubmitTransactionResult;
import com.amex.internal.b9.libra.admissioncontrol.transaction.Transaction;
import com.amex.internal.b9.libra.admissioncontrol.transaction.U64Argument;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import org.bouncycastle.util.encoders.Hex;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static java.time.Instant.now;
import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;


public class LibraClient {

    private static final Logger logger = LogManager.getLogger(LibraClient.class);

    private final LibraLibConfig config;
    private final ManagedChannel channel;
    private AdmissionControl admissionControl;

    @SuppressWarnings("checkstyle:MagicNumber")
    public LibraClient() {
        this(new LibraLibConfig("ac.testnet.libra.org", 8000, LibraNetwork.testnet, "faucet.testnet.libra.org"));
    }

    public LibraClient(LibraLibConfig config) {
        this.config = config;
        this.channel = ManagedChannelBuilder.forAddress(this.config.getHost(), this.config.getPort()).usePlaintext().build();
        this.admissionControl = new AdmissionControl(channel);
    }

    public long findBalance(String forAddress) {
        UpdateToLatestLedgerResult result = admissionControl.updateToLatestLedger(
                ImmutableQuery.builder().addAccountStateQueries(
                        ImmutableGetAccountState.builder().address(Hex.decode(forAddress)).build()).build());

        long balance = result.getAccountStates()
                .stream()
                .filter(accountState -> Arrays.equals(
                        accountState.getAccountAddress(),
                        Hex.decode(forAddress)))
                .map(AccountData::getBalanceInMicroLibras)
                .findFirst()
                .orElse(0L);

        logger.info("Balance for {} is {}", forAddress, balance);

        return balance;
    }

    public List<AccountData> getAccountStates( String address ) {

        UpdateToLatestLedgerResult result = this.admissionControl
                .updateToLatestLedger(ImmutableQuery.builder()
                        .addAccountStateQueries(ImmutableGetAccountState.builder()
                                .address(Hex.decode(address))
                                .build())
                        .build());

        result.getAccountStates().forEach(accountState -> {
            logger.info("Address: {}", Hex.toHexString(accountState.getAccountAddress()));
            logger.info("Received events: {}", accountState.getReceivedEvents().getCount());
            logger.info("Sent events: {}", accountState.getSentEvents().getCount());
            logger.info("Balance (microLibras): {}", accountState.getBalanceInMicroLibras());
            logger.info("Balance (Libras): {}",
                    new BigDecimal(accountState.getBalanceInMicroLibras()).divide(BigDecimal.valueOf(1000000)));
            logger.info("Sequence number: {}", accountState.getSequenceNumber());
            logger.info("Delegated withdrawal capability: {}", accountState.getDelegatedWithdrawalCapability());
        });

        return result.getAccountStates();
    }

    public List<SignedTransactionWithProof> getTransactionBySequenceNumber( String address, int sequenceNumber ) {


        UpdateToLatestLedgerResult result = this.admissionControl.updateToLatestLedger(ImmutableQuery.builder()
                .addAccountTransactionBySequenceNumberQueries(
                        ImmutableGetAccountTransactionBySequenceNumber.builder()
                                .accountAddress(Hex.decode(address))
                                .sequenceNumber(sequenceNumber)
                                .build())
                .build());


        result.getAccountTransactionsBySequenceNumber().forEach(tx -> {
            logger.info("Sender public key: " + Hex.toHexString(tx.getSenderPublicKey()));
            logger.info("Sender signature: " + Hex.toHexString(tx.getSenderSignature()));
            tx.getEvents()
                    .forEach(e -> logger.info("{}: Sequence number: {}, Amount: {}",
                            Hex.toHexString(e.getAccountAddress()), e.getSequenceNumber(), e.getAmount()));
        });

        return result.getAccountTransactionsBySequenceNumber();
    }

    public long mintWithFaucetService(String receiver, long amountInMicroLibras) {

        HttpResponse<String> response = Unirest.post("http://faucet.testnet.libra.org")
                .queryString("amount", amountInMicroLibras  )
                .queryString("address", receiver)
                .asString();

        return 1;

//        with().pollInterval( fibonacci().with().timeUnit(SECONDS)).await()
//                .atMost(1, MINUTES)
//                .until(() -> findBalance( sourceAccount.getAddress()) > 0);

        //assertEquals(200, response.getStatus());


//        OkHttpClient client = new OkHttpClient();
//        Request request = new Request.Builder()
//                .url(String.format("http://%s?amount=%s&address=%s", this.config.getFaucetServerHost(), amount, receiver))
//                .build();
//        try {
//            Response response = client.newCall(request).execute();
//            return Long.parseLong(response.body().string());
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
    }

    /**
     * Transfer coins from sender to receipient.
     * @param sender
     * @param recipientAddress
     * @param amount should be in libraCoins based unit.
     * @return SubmitTransactionResponse
     */
    public String transferCoins( Account sender, String recipientAddress, long amount)  {

        // make the transaction
        return transfer( sender, recipientAddress, amount * 1_000_000 ).name();

    }


    private AdmissionControlOuterClass.AdmissionControlStatusCode transfer(Account sender, String recipientAddress, long amountInMicroLibras ) {

        long sequenceNumber = maybeFindSequenceNumber( sender.getAddress() );

        // Arguments for the peer to peer transaction
        U64Argument amountArgument = new U64Argument( amountInMicroLibras );
        AddressArgument addressArgument = new AddressArgument(Hex.decode(recipientAddress));

        Transaction transaction = ImmutableTransaction.builder()
                .sequenceNumber(sequenceNumber)
                .maxGasAmount(600000)
                .gasUnitPrice(1)
                .expirationTime(now().getEpochSecond() + 1000)
                .program(
                        ImmutableProgram.builder()
                                .code(ByteString.copyFrom(Move.peerToPeerTransferAsBytes()))
                                .addArguments(addressArgument, amountArgument)
                                .build())
                .build();

        SubmitTransactionResult result = admissionControl.submitTransaction( sender.getKeyPair().publicKey,
                sender.getKeyPair().privateKey, transaction);

        System.out.println("Transaction submitted with result: " + result.toString());

        return result.getAdmissionControlStatus().getCode();
    }


    private long maybeFindSequenceNumber(  String forAddress) {

        UpdateToLatestLedgerResult result = this.admissionControl.updateToLatestLedger(
                ImmutableQuery.builder().addAccountStateQueries(
                        ImmutableGetAccountState.builder().address(Hex.decode(forAddress)).build()).build());

        return result.getAccountStates()
                .stream()
                .filter(accountState -> Arrays.equals(
                        accountState.getAccountAddress(),
                        Hex.decode(forAddress)))
                .map(AccountData::getSequenceNumber)
                .findFirst()
                .orElse(0);
    }


    /**
     * Uses the faucetService on testnet to mint coins to be sent to receiver. and wait for confirmation
     *
     * @param receiver receiver address
     * @param amount   numCoins should be in base unit i.e microlibra
     * @return the sequence number for the transaction used to mint
     */
    @SuppressWarnings("checkstyle:MagicNumber")
    public long mintWithFaucetServiceAndWaitForConfirmation(String receiver, long amount) {
        long transactionSequenceNumber = this.mintWithFaucetService(receiver, amount);
        this.waitForConfirmation(Account.DEFAULT_ADDRESS, transactionSequenceNumber, 50);
        return transactionSequenceNumber;
    }

    /**
     * Keeps polling the account state of address till sequenceNumber is computed.
     * @param address
     * @param transactionSequenceNumber
     * @param maxIterations
     */
    public void waitForConfirmation(String address, long transactionSequenceNumber, int maxIterations) {

//        if (this.getAccountResource(address).getSequenceNumber() >= transactionSequenceNumber) {
//            return;
//        }
        if (maxIterations == -1) {
            throw new RuntimeException(String.format("Confirmation timeout for [%s]:[%s]", address, transactionSequenceNumber));
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        waitForConfirmation(address, transactionSequenceNumber, --maxIterations);
    }


    @SuppressWarnings("checkstyle:MagicNumber")
    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, SECONDS);
    }


}

