package com.amex.internal.b9.libra.wallet;

import com.amex.internal.b9.libra.mnemonic.Mnemonic;
import lombok.Data;

@Data
public class WalletConfig {
    private final Mnemonic mnemonic;
    private final String salt;

    public WalletConfig(Mnemonic mnemonic, String salt) {
        this.mnemonic = mnemonic;
        this.salt = salt;
    }
}
