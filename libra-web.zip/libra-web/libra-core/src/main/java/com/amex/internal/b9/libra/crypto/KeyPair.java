package com.amex.internal.b9.libra.crypto;

import net.i2p.crypto.eddsa.EdDSAEngine;
import net.i2p.crypto.eddsa.EdDSAPrivateKey;
import net.i2p.crypto.eddsa.EdDSAPublicKey;
import net.i2p.crypto.eddsa.spec.EdDSANamedCurveTable;
import net.i2p.crypto.eddsa.spec.EdDSAParameterSpec;
import net.i2p.crypto.eddsa.spec.EdDSAPrivateKeySpec;
import net.i2p.crypto.eddsa.spec.EdDSAPublicKeySpec;

import java.security.MessageDigest;
import java.security.Signature;

public class KeyPair {
    public final EdDSAPrivateKey privateKey;
    public final EdDSAPublicKey publicKey;

    public KeyPair(EdDSAPrivateKey privateKey, EdDSAPublicKey publicKey) {
        this.privateKey = privateKey;
        this.publicKey = publicKey;
    }

    public static KeyPair fromSecretKey(byte[] secretKey) {
        EdDSAPrivateKeySpec privKeySpec = new EdDSAPrivateKeySpec(secretKey, EdDSANamedCurveTable.ED_25519_CURVE_SPEC);
        EdDSAPublicKeySpec publicKeySpec = new EdDSAPublicKeySpec(privKeySpec.getA().toByteArray(),
                EdDSANamedCurveTable.ED_25519_CURVE_SPEC);
        EdDSAPrivateKey privateKey = new EdDSAPrivateKey(privKeySpec);
        EdDSAPublicKey publicKey = new EdDSAPublicKey(publicKeySpec);
        return new KeyPair(privateKey, publicKey);
    }

    public byte[] getPublicKey() {
        return this.publicKey.getAbyte();
    }

    public byte[] getPrivateKey() {
        return this.privateKey.geta();
    }

    public byte[] sign(byte[] message) {
        try {
            EdDSAParameterSpec spec = EdDSANamedCurveTable.getByName(EdDSANamedCurveTable.ED_25519);
            Signature sgr = new EdDSAEngine(MessageDigest.getInstance(spec.getHashAlgorithm()));
            byte[] signature;
            sgr.initSign(this.privateKey);
            sgr.update(message);
            signature = sgr.sign();
            return signature;
        } catch (Exception e) {
            throw new RuntimeException("Signing the message failed", e);
        }
    }
}
