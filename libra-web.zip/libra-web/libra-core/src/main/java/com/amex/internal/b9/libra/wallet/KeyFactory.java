package com.amex.internal.b9.libra.wallet;


import com.amex.internal.b9.libra.constants.KeyPrefixes;
import com.amex.internal.b9.libra.crypto.BouncyCastlePBKDF2WithHmac;
import com.amex.internal.b9.libra.crypto.KeyPair;
import com.amex.internal.b9.libra.mnemonic.Mnemonic;
import com.google.common.primitives.Bytes;
import io.netty.util.internal.StringUtil;
import org.bouncycastle.crypto.digests.SHA3Digest;
import org.bouncycastle.crypto.generators.HKDFBytesGenerator;
import org.bouncycastle.crypto.macs.HMac;
import org.bouncycastle.crypto.params.HKDFParameters;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.Security;
import java.text.Normalizer;

public class KeyFactory {
    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    private final byte[] masterPrivKey;

    public KeyFactory(byte[] seed) {
        try {
            HMac hmac = new HMac(new SHA3Digest(256));
            this.masterPrivKey = new byte[hmac.getMacSize()];
            hmac.init(new KeyParameter(KeyPrefixes.MASTER_KEY_SALT.getBytes(StandardCharsets.UTF_8)));
            hmac.update(seed, 0, seed.length);
            hmac.doFinal(this.masterPrivKey, 0);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static KeyFactory fromMnemonic(Mnemonic mnemonic, String salt) {
        return fromMnemonic(mnemonic.toString(), salt);
    }

    private static KeyFactory fromMnemonic(String mnemonic, String salt) {
        salt = KeyPrefixes.MNEMONIC_SALT + (StringUtil.isNullOrEmpty(salt) ? KeyPrefixes.DEFAULT_MNEMONIC_SALT_PREFIX : salt);
        String parsedSalt = Normalizer.normalize(salt, Normalizer.Form.NFKD);
        byte[] seed = BouncyCastlePBKDF2WithHmac.PBKDF2WithHmacSHA3_256.hash(
                Normalizer.normalize(mnemonic, Normalizer.Form.NFKD).toCharArray(),
                parsedSalt.getBytes(StandardCharsets.UTF_8));
        return new KeyFactory(seed);
    }

    /**
     * Generates a new key pair at the number position.
     *
     * @param childDepth
     * @return keyPair
     */
    public KeyPair generateKey(long childDepth) {
        byte[] infoBytes = KeyPrefixes.DERIVED_KEY.getBytes(StandardCharsets.UTF_8);
        infoBytes = Bytes.concat(infoBytes, ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(childDepth).array());
        HKDFBytesGenerator hkdfBytesGenerator = new HKDFBytesGenerator(new SHA3Digest(256));
        hkdfBytesGenerator.init(HKDFParameters.skipExtractParameters(this.masterPrivKey, infoBytes));
        byte[] secretKey = new byte[32];
        hkdfBytesGenerator.generateBytes(secretKey, 0, 32);
        return KeyPair.fromSecretKey(secretKey);
    }
}
