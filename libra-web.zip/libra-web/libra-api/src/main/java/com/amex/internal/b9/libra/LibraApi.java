package com.amex.internal.b9.libra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraApi {
    public static void main(String[] args) {
        SpringApplication.run(LibraApi.class, args);
    }
}
