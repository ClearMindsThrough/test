package com.amex.internal.b9.libra.controller;


import com.amex.internal.b9.libra.admissioncontrol.query.SignedTransactionWithProof;
import com.amex.internal.b9.libra.client.LibraClient;
import com.amex.internal.b9.libra.wallet.Account;
import com.amex.internal.b9.libra.wallet.LibraWallet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.amex.internal.b9.libra.admissioncontrol.query.AccountData;

import java.util.List;


@RestController
@RequestMapping( value = "/accounts" )
public class AccountsController {

    private static final Logger logger = LogManager.getLogger(AccountsController.class);

    @GetMapping( "/address" )
    public ResponseEntity<String> newAccountAddress() {
        LibraWallet libraWallet = new LibraWallet(
                "gentle vault ginger glide creek kind wink focus crumble stock cute praise inquiry shock quality steel ocean hand school inform slab either alpha catalog"
        );
        Account account = libraWallet.newAccount();

        return new ResponseEntity<>( account.getAddress(), HttpStatus.CREATED);
    }

    @GetMapping( "/full" )
    public ResponseEntity<Account> newAccount() {
        LibraWallet libraWallet = new LibraWallet(
                "gentle vault ginger glide creek kind wink focus crumble stock cute praise inquiry shock quality steel ocean hand school inform slab either alpha catalog"
        );
        Account account = libraWallet.newAccount();

        logger.info( "the new account address is: {}", account.getAddress() );

        return new ResponseEntity<>( account, HttpStatus.CREATED);
    }

    @GetMapping( "/{address}/mints/{amount}" )
    public ResponseEntity<Long> mintAccount( @PathVariable("address") String address, @PathVariable("amount")long amount ) {


        long sequenceNumber = new LibraClient().mintWithFaucetService( address, amount * 1_000_000 );

        return new ResponseEntity<>( sequenceNumber, HttpStatus.OK);

    }

    @GetMapping( "/{address}/balances" )
    public ResponseEntity<Long> findAccountBalance( @PathVariable("address") String address ) {


        long balance = new LibraClient().findBalance( address );

        return new ResponseEntity<>( balance / 1_000_000, HttpStatus.OK);
    }

    @GetMapping( "/{address}/states" )
    public ResponseEntity<List<AccountData>> findAccountStates(@PathVariable("address") String address ) {

        List<AccountData> data = new LibraClient().getAccountStates( address );

        return new ResponseEntity<>( data, HttpStatus.OK);
    }
    @GetMapping( "/{address}/transactions/{sequence}/states" )
    public ResponseEntity<List<SignedTransactionWithProof>> getTransactionBySequenceNumber(@PathVariable("address") String address, @PathVariable("sequence") int sequence ) {

        List<SignedTransactionWithProof> transactions = new LibraClient().getTransactionBySequenceNumber( address, sequence );

        return new ResponseEntity<>( transactions, HttpStatus.OK);
    }

    @GetMapping( value = "/transfers/{address}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> accountTransfer( @PathVariable( "address") String address  ) {

//    @PostMapping( value = "/transfers", consumes = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<String> accountTransfer( @RequestBody AccountTransferRequest request  ) {

        LibraWallet libraWallet = new LibraWallet(
                "gentle vault ginger glide creek kind wink focus crumble stock cute praise inquiry shock quality steel ocean hand school inform slab either alpha catalog"
        );
        Account account = libraWallet.newAccount();

        logger.info( "the new account address is: {}", account.getAddress() );

        mintAccount( account.getAddress(), 1000 );

//        String code = new LibraClient().transferCoins( request.getSender(), request.getToAddress(), request.getAmount() );
        String code = new LibraClient().transferCoins( account, address, 8 );

        return new ResponseEntity<>( code, HttpStatus.CREATED);
    }

}
