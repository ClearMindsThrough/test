package com.amex.internal.b9.libra.controller;

import com.amex.internal.b9.libra.wallet.LibraWallet;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping( value = "/wallet" )
public class LibraWalletController {


    @PostMapping( "/" )
    public ResponseEntity<LibraWallet> wallet() {
        LibraWallet libraWallet = new LibraWallet(
                "gentle vault ginger glide creek kind wink focus crumble stock cute praise inquiry shock quality steel ocean hand school inform slab either alpha catalog"
        );

        return new ResponseEntity<>(libraWallet, HttpStatus.CREATED);
    }


}
