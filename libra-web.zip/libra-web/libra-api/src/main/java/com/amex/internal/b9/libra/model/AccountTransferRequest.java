package com.amex.internal.b9.libra.model;

import com.amex.internal.b9.libra.wallet.Account;
import lombok.Data;

@Data
public class AccountTransferRequest {

    Account sender;
    String toAddress;
    long amount;
}
